/* ============================================================================
 *  canvas.cpp  --  Windows-native backend for SimpleCpp
 *
 *  Drop-in replacement for the original Xlib-based canvas.cpp.  It implements
 *  exactly the interface declared in canvas.h using the Win32 API + GDI, so
 *  every other SimpleCpp source file and every user program compiles and
 *  links unchanged.
 *
 *  Double-buffered model, mirroring the original:
 *      screenBG   -- background bitmap (imprinted lines / cleared canvas)
 *      screenTmp  -- per-frame composite (BG + all sprites)
 *      window     -- what the user sees; screenTmp is blitted onto it
 *  `curr_d' is the device context primitives currently draw into, exactly as
 *  the X version used a Drawable.
 *
 *  The event loop is single-threaded: Win32 messages are pumped whenever the
 *  user program calls into the library (wait / nextEvent / checkEvent / ...),
 *  which is how SimpleCpp programs are structured.
 * ==========================================================================*/

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <simplecpp>
#include <windows.h>
#include <windowsx.h>          /* GET_X_LPARAM / GET_Y_LPARAM */

#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <deque>
#include <string>

using namespace std;

/* ------------------------------------------------------------------------- */
/*  Backend state (file scope, replacing the old X globals)                  */
/* ------------------------------------------------------------------------- */

static HINSTANCE  hInst         = NULL;
static HWND       canvas_window = NULL;

int   screen_width  = 0;   /* non-static: preserves old external linkage */
int   screen_height = 0;

static HDC        hdcWin = NULL;   /* window DC (class uses CS_OWNDC) */
static HDC        hdcBG  = NULL;   /* memory DC holding screenBG bitmap */
static HDC        hdcTmp = NULL;   /* memory DC holding screenTmp bitmap */
static HBITMAP    bmBG   = NULL;
static HBITMAP    bmTmp  = NULL;
static HFONT      hFont  = NULL;

/* The drawable primitives currently render into. */
static HDC        curr_d = NULL;

/* Input plumbing */
static const unsigned int SC_SHIFT_MASK = 0x0001;
static const unsigned int SC_CTRL_MASK  = 0x0002;
static const unsigned int SC_ALT_MASK   = 0x0004;

static std::deque<XEvent> eventQueue;
static int  lastMouseX = 0, lastMouseY = 0;
static bool windowClosed = false;

/* z-ordered set of live sprites (unchanged from original) */
struct LtSprite {
  bool operator()(const simplecpp::Sprite* s1,
                  const simplecpp::Sprite* s2) const {
    return s1->getZIndex() < s2->getZIndex();
  }
};
static std::multiset<simplecpp::Sprite *, LtSprite> spriteSet;

/* ------------------------------------------------------------------------- */
/*  Small helpers                                                            */
/* ------------------------------------------------------------------------- */

/* SimpleCpp Color is 0x00RRGGBB; GDI COLORREF is 0x00BBGGRR. */
static inline COLORREF toColorRef(simplecpp::Color c) {
  return RGB((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF);
}

static unsigned int currentModifierMask() {
  unsigned int m = 0;
  if (GetKeyState(VK_SHIFT)   & 0x8000) m |= SC_SHIFT_MASK;
  if (GetKeyState(VK_CONTROL) & 0x8000) m |= SC_CTRL_MASK;
  if (GetKeyState(VK_MENU)    & 0x8000) m |= SC_ALT_MASK;
  return m;
}

/* Named-colour table (subset of X11 rgb.txt covering everything the
 * SimpleCpp examples and typical student code use). */
struct NamedColor { const char* name; unsigned char r, g, b; };
static const NamedColor kNamedColors[] = {
  {"black",       0,   0,   0  }, {"white",     255, 255, 255},
  {"red",         255, 0,   0  }, {"green",       0, 255,   0},
  {"blue",        0,   0,   255}, {"yellow",    255, 255,   0},
  {"cyan",        0,   255, 255}, {"magenta",   255,   0, 255},
  {"orange",      255, 165, 0  }, {"purple",    160,  32, 240},
  {"pink",        255, 192, 203}, {"brown",     165,  42,  42},
  {"gray",        190, 190, 190}, {"grey",      190, 190, 190},
  {"darkgray",    169, 169, 169}, {"darkgrey",  169, 169, 169},
  {"lightgray",   211, 211, 211}, {"lightgrey", 211, 211, 211},
  {"darkgreen",   0,   100, 0  }, {"lightblue", 173, 216, 230},
  {"navy",        0,   0,   128}, {"gold",      255, 215,   0},
  {"silver",      192, 192, 192}, {"maroon",    128,   0,   0},
  {"olive",       128, 128, 0  }, {"teal",        0, 128, 128},
  {"violet",      238, 130, 238}, {"indigo",     75,   0, 130},
  {"turquoise",   64,  224, 208}, {"salmon",    250, 128, 114},
  {"skyblue",     135, 206, 235}, {"tan",       210, 180, 140},
  {"beige",       245, 245, 220}, {"coral",     255, 127,  80},
  {"crimson",     220, 20,  60 }, {"khaki",     240, 230, 140},
  {"lime",        0,   255, 0  }, {"chocolate", 210, 105,  30},
};

/* Parse "#rrggbb" if given, else look up the name; default black. */
static simplecpp::Color colorFromName(const char* s) {
  if (s && s[0] == '#') {
    unsigned int v = 0;
    sscanf(s + 1, "%x", &v);
    return (simplecpp::Color)(v & 0xFFFFFF);
  }
  if (s) {
    for (const NamedColor& nc : kNamedColors)
      if (_stricmp(s, nc.name) == 0)
        return simplecpp::COLOR(nc.r, nc.g, nc.b);
  }
  return simplecpp::COLOR(0, 0, 0);
}

/* Push translated input events onto the queue. */
static void pushButton(int type, int button, int x, int y) {
  XEvent e; memset(&e, 0, sizeof(e));
  e.type = type;
  e.xbutton.type   = type;
  e.xbutton.button = button;
  e.xbutton.x = x; e.xbutton.y = y;
  e.xbutton.time   = (XTime)GetTickCount();
  e.xbutton.state  = currentModifierMask();
  eventQueue.push_back(e);
}
static void pushKey(int type, unsigned int vk, int x, int y) {
  XEvent e; memset(&e, 0, sizeof(e));
  e.type = type;
  e.xkey.type    = type;
  e.xkey.keycode = vk;
  e.xkey.state   = currentModifierMask();
  e.xkey.x = x; e.xkey.y = y;
  e.xkey.time    = (XTime)GetTickCount();
  eventQueue.push_back(e);
}
static void pushMotion(int x, int y) {
  XEvent e; memset(&e, 0, sizeof(e));
  e.type = MotionNotify;
  e.xmotion.type = MotionNotify;
  e.xmotion.x = x; e.xmotion.y = y;
  e.xmotion.time  = (XTime)GetTickCount();
  e.xmotion.state = currentModifierMask();
  eventQueue.push_back(e);
}

/* ------------------------------------------------------------------------- */
/*  Window procedure                                                         */
/* ------------------------------------------------------------------------- */

static LRESULT CALLBACK CanvasWndProc(HWND hwnd, UINT msg,
                                      WPARAM wParam, LPARAM lParam) {
  switch (msg) {
    case WM_PAINT: {
      PAINTSTRUCT ps;
      HDC dc = BeginPaint(hwnd, &ps);
      if (hdcTmp)
        BitBlt(dc, 0, 0, screen_width, screen_height, hdcTmp, 0, 0, SRCCOPY);
      EndPaint(hwnd, &ps);
      return 0;
    }
    case WM_MOUSEMOVE:
      lastMouseX = GET_X_LPARAM(lParam);
      lastMouseY = GET_Y_LPARAM(lParam);
      if (wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON))
        pushMotion(lastMouseX, lastMouseY);  /* X used ButtonMotionMask */
      return 0;

    case WM_LBUTTONDOWN:
      pushButton(ButtonPress, Button1, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;
    case WM_MBUTTONDOWN:
      pushButton(ButtonPress, Button2, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;
    case WM_RBUTTONDOWN:
      pushButton(ButtonPress, Button3, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;
    case WM_LBUTTONUP:
      pushButton(ButtonRelease, Button1, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;
    case WM_MBUTTONUP:
      pushButton(ButtonRelease, Button2, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;
    case WM_RBUTTONUP:
      pushButton(ButtonRelease, Button3, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)); return 0;

    case WM_MOUSEWHEEL: {
      int delta = GET_WHEEL_DELTA_WPARAM(wParam);
      pushButton(ButtonPress, delta > 0 ? Button4 : Button5, lastMouseX, lastMouseY);
      return 0;
    }

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
      pushKey(KeyPress, (unsigned int)wParam, lastMouseX, lastMouseY); return 0;
    case WM_KEYUP:
    case WM_SYSKEYUP:
      pushKey(KeyRelease, (unsigned int)wParam, lastMouseX, lastMouseY); return 0;

    case WM_CLOSE:
      windowClosed = true;
      DestroyWindow(hwnd);
      return 0;
    case WM_DESTROY:
      windowClosed = true;
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProc(hwnd, msg, wParam, lParam);
}

/* Drain all pending Win32 messages into eventQueue. */
static void pumpMessages() {
  MSG msg;
  while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
    if (msg.message == WM_QUIT) { windowClosed = true; break; }
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
}

/* If the user closed the window, terminate the program cleanly. */
static void bailIfClosed() { if (windowClosed) std::exit(0); }

/* ========================================================================= */
namespace simplecpp {

  double randuv(double u, double v) {
    return u + (v - u) * rand() / (1.0 + RAND_MAX);
  }

  void abort() { std::abort(); }

  int canvas_width()  { return screen_width;  }
  int canvas_height() { return screen_height; }

  void wait(float duration) {
    if (duration <= 0) { pumpMessages(); bailIfClosed(); return; }
    DWORD start = GetTickCount();
    DWORD total = (DWORD)(duration * 1000.0f);
    for (;;) {
      pumpMessages();
      bailIfClosed();
      DWORD elapsed = GetTickCount() - start;
      if (elapsed >= total) break;
      DWORD remain = total - elapsed;
      Sleep(remain > 5 ? 5 : remain);  /* small slices keep the window alive */
    }
  }

  /* ----------------------------------------------------------------------- */
  int initCanvas(const char window_title[], int width, int height) {
    hInst = GetModuleHandle(NULL);

    if (width == -1) {
      screen_width  = GetSystemMetrics(SM_CXSCREEN) - 100;
      screen_height = GetSystemMetrics(SM_CYSCREEN) - 100;
    } else {
      screen_width  = width;
      screen_height = height;
    }

    WNDCLASSA wc; memset(&wc, 0, sizeof(wc));
    wc.style         = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = CanvasWndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wc.lpszClassName = "SimpleCppCanvas";
    RegisterClassA(&wc);   /* harmless if already registered */

    /* Size the window so the *client* area is exactly width x height. */
    RECT r = { 0, 0, screen_width, screen_height };
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    AdjustWindowRect(&r, style, FALSE);

    canvas_window = CreateWindowA(
        "SimpleCppCanvas", window_title, style,
        CW_USEDEFAULT, CW_USEDEFAULT,
        r.right - r.left, r.bottom - r.top,
        NULL, NULL, hInst, NULL);

    if (!canvas_window) { cerr << "Unable to create canvas window\n"; return 1; }

    ShowWindow(canvas_window, SW_SHOW);
    UpdateWindow(canvas_window);

    hdcWin = GetDC(canvas_window);          /* persistent (CS_OWNDC) */

    hdcBG  = CreateCompatibleDC(hdcWin);
    hdcTmp = CreateCompatibleDC(hdcWin);
    bmBG   = CreateCompatibleBitmap(hdcWin, screen_width, screen_height);
    bmTmp  = CreateCompatibleBitmap(hdcWin, screen_width, screen_height);
    SelectObject(hdcBG,  bmBG);
    SelectObject(hdcTmp, bmTmp);

    RECT full = { 0, 0, screen_width, screen_height };
    HBRUSH wb = (HBRUSH)GetStockObject(WHITE_BRUSH);
    FillRect(hdcBG,  &full, wb);
    FillRect(hdcTmp, &full, wb);

    /* Bold ~20px font, roughly matching the old helvetica-bold-24. */
    hFont = CreateFontA(-20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                        ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");

    HDC dcs[3] = { hdcWin, hdcBG, hdcTmp };
    for (HDC d : dcs) { SelectObject(d, hFont); SetBkMode(d, TRANSPARENT); }

    curr_d = hdcWin;

    pumpMessages();
    return 0;
  }

  void closeCanvas() {
    if (hFont)  { DeleteObject(hFont);  hFont  = NULL; }
    if (hdcBG)  { DeleteDC(hdcBG);      hdcBG  = NULL; }
    if (hdcTmp) { DeleteDC(hdcTmp);     hdcTmp = NULL; }
    if (bmBG)   { DeleteObject(bmBG);   bmBG   = NULL; }
    if (bmTmp)  { DeleteObject(bmTmp);  bmTmp  = NULL; }
    if (canvas_window && hdcWin) { ReleaseDC(canvas_window, hdcWin); hdcWin = NULL; }
    if (canvas_window) { DestroyWindow(canvas_window); canvas_window = NULL; }
    spriteSet.clear();
  }

  /* ------------------------------- colours ------------------------------- */
  Color COLOR(const char *color_string) { return colorFromName(color_string); }
  Color COLOR(unsigned int red, unsigned int green, unsigned int blue) {
    return (Color)((red & 0xFF) << 16 | (green & 0xFF) << 8 | (blue & 0xFF));
  }

  /* ------------------------------- drawing ------------------------------- */
  void drawLine(XPoint start, XPoint end, Color line_color, unsigned int line_width) {
    int w = line_width ? (int)line_width : 1;
    HPEN pen = CreatePen(PS_SOLID, w, toColorRef(line_color));
    HGDIOBJ old = SelectObject(curr_d, pen);
    MoveToEx(curr_d, start.x, start.y, NULL);
    LineTo(curr_d, end.x, end.y);
    SelectObject(curr_d, old);
    DeleteObject(pen);
  }

  void imprintLine(short x1, short y1, short x2, short y2,
                   Color line_color, unsigned int line_width) {
    HDC temp = curr_d; curr_d = hdcBG;
    XPoint a = { x1, y1 }, b = { x2, y2 };
    drawLine(a, b, line_color, line_width);
    curr_d = temp;
  }

  void drawPoint(XPoint point, Color point_color, int /*function*/) {
    SetPixel(curr_d, point.x, point.y, toColorRef(point_color));
  }

  void drawCircle(XPoint centre, int radius, Color fill_color, bool fill,
                  unsigned int line_width, int, int, int, int) {
    int w = line_width ? (int)line_width : 1;
    COLORREF cr = toColorRef(fill_color);
    HPEN   pen   = CreatePen(PS_SOLID, w, cr);
    HBRUSH brush = fill ? CreateSolidBrush(cr) : (HBRUSH)GetStockObject(NULL_BRUSH);
    HGDIOBJ op = SelectObject(curr_d, pen);
    HGDIOBJ ob = SelectObject(curr_d, brush);
    ::Ellipse(curr_d, centre.x - radius, centre.y - radius,
                      centre.x + radius, centre.y + radius);
    SelectObject(curr_d, op); SelectObject(curr_d, ob);
    DeleteObject(pen); if (fill) DeleteObject(brush);
  }

  void drawEllipse(XPoint centre, int width, int height, Color fill_color,
                   bool fill, unsigned int line_width, int, int, int, int) {
    int w = line_width ? (int)line_width : 1;
    COLORREF cr = toColorRef(fill_color);
    HPEN   pen   = CreatePen(PS_SOLID, w, cr);
    HBRUSH brush = fill ? CreateSolidBrush(cr) : (HBRUSH)GetStockObject(NULL_BRUSH);
    HGDIOBJ op = SelectObject(curr_d, pen);
    HGDIOBJ ob = SelectObject(curr_d, brush);
    ::Ellipse(curr_d, centre.x - width / 2, centre.y - height / 2,
                      centre.x + width / 2, centre.y + height / 2);
    SelectObject(curr_d, op); SelectObject(curr_d, ob);
    DeleteObject(pen); if (fill) DeleteObject(brush);
  }

  void drawPolygon(XPoint *points, int npoints, Color fill_color, bool fill,
                   unsigned int line_width, int, int, int, int fill_rule, int) {
    if (npoints <= 0) return;
    POINT *pts = new POINT[npoints + 1];
    for (int i = 0; i < npoints; ++i) { pts[i].x = points[i].x; pts[i].y = points[i].y; }

    int w = line_width ? (int)line_width : 1;
    COLORREF cr = toColorRef(fill_color);
    HPEN pen = CreatePen(PS_SOLID, w, cr);
    HGDIOBJ op = SelectObject(curr_d, pen);

    if (fill) {
      HBRUSH brush = CreateSolidBrush(cr);
      HGDIOBJ ob = SelectObject(curr_d, brush);
      SetPolyFillMode(curr_d, fill_rule == WindingRule ? WINDING : ALTERNATE);
      ::Polygon(curr_d, pts, npoints);
      SelectObject(curr_d, ob);
      DeleteObject(brush);
    } else {
      pts[npoints] = pts[0];                 /* close the outline */
      ::Polyline(curr_d, pts, npoints + 1);
    }
    SelectObject(curr_d, op);
    DeleteObject(pen);
    delete[] pts;
  }

  /* ------------------------------- sprites ------------------------------- */
  void addSprite(Sprite *t) { if (t) spriteSet.insert(t); }

  void removeSprite(Sprite *t) {
    if (t)
      for (auto it = spriteSet.begin(); it != spriteSet.end(); ++it)
        if (*it == t) { spriteSet.erase(it); break; }
    repaint();
  }

  void c_imprint(Sprite* s) {
    HDC temp = curr_d; curr_d = hdcBG;
    s->paint();
    curr_d = temp;
  }

  static bool globalRepaintFlag = true;
  void beginFrame() { globalRepaintFlag = false; }
  void endFrame()   { globalRepaintFlag = true; repaint(); }

  void repaint() {
    if (!canvas_window) {
      cout << "Repaint: You must first call initCanvas before "
              "using any graphics features.\n";
      exit(1);
    }
    if (!globalRepaintFlag) return;

    BitBlt(hdcTmp, 0, 0, screen_width, screen_height, hdcBG, 0, 0, SRCCOPY);
    curr_d = hdcTmp;
    for (auto it = spriteSet.begin(); it != spriteSet.end(); ++it)
      (*it)->paint();

    BitBlt(hdcWin, 0, 0, screen_width, screen_height, hdcTmp, 0, 0, SRCCOPY);
    curr_d = hdcWin;

    pumpMessages();
    bailIfClosed();
  }

  /* -------------------------------- events ------------------------------- */
  void nextEvent(XEvent &event) {
    for (;;) {
      pumpMessages();
      bailIfClosed();
      if (!eventQueue.empty()) {
        event = eventQueue.front();
        eventQueue.pop_front();
        return;
      }
      Sleep(2);
    }
  }

  bool checkEvent(XEvent &event) {
    pumpMessages();
    bailIfClosed();
    for (auto it = eventQueue.begin(); it != eventQueue.end(); ++it) {
      int t = it->type;
      if (t == ButtonPress || t == ButtonRelease || t == KeyPress) {
        event = *it;
        eventQueue.erase(it);
        return true;
      }
    }
    return false;
  }

  char charFromEvent(XEvent &event) {
    unsigned int vk = event.xkey.keycode;
    UINT mapped = MapVirtualKey(vk, MAPVK_VK_TO_CHAR);
    char c = (char)(mapped & 0x7FFF);
    if (c == 0) return 0;
    bool shift = (event.xkey.state & SC_SHIFT_MASK) != 0;
    if (!shift && c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return c;
  }

  void echoKey(XEvent &event, Color clr) {
    char c = charFromEvent(event);
    if (!c) return;
    drawText((float)event.xkey.x, (float)event.xkey.y, string(1, c), clr);
  }

  /* ------------------------------- text ---------------------------------- */
  int textWidth(string text) {
    SIZE sz = { 0, 0 };
    GetTextExtentPoint32A(curr_d ? curr_d : hdcWin, text.c_str(), (int)text.size(), &sz);
    return sz.cx;
  }
  int textWidth(char op) { string s(1, op); return textWidth(s); }

  int textHeight() {
    TEXTMETRIC tm; GetTextMetrics(curr_d ? curr_d : hdcWin, &tm);
    return tm.tmAscent + tm.tmDescent;
  }
  int textDescent() {
    TEXTMETRIC tm; GetTextMetrics(curr_d ? curr_d : hdcWin, &tm);
    return tm.tmDescent;
  }

  void drawText(XPoint position, string message, Color clr) {
    SIZE sz = { 0, 0 };
    GetTextExtentPoint32A(curr_d, message.c_str(), (int)message.size(), &sz);
    SetTextColor(curr_d, toColorRef(clr));
    SetBkMode(curr_d, TRANSPARENT);
    TextOutA(curr_d, position.x - sz.cx / 2, position.y - sz.cy / 2,
             message.c_str(), (int)message.size());   /* centred on point */
  }

  void drawText(float x, float y, string text, Color clr) {
    XPoint p; p.x = (short)x; p.y = (short)y;
    drawText(p, text, clr);
  }

  /* ------------------------------- misc ---------------------------------- */
  void spriteStatus() {
    cout << "Count: " << spriteSet.size() << endl;
    for (auto it = spriteSet.begin(); it != spriteSet.end(); ++it)
      cout << "[" << "]-->" << (*it) << endl;
  }

  bool mouseDragEvent(XEvent &event)          { return event.type == MotionNotify; }
  bool mouseButtonPressEvent(XEvent &event)   { return event.type == ButtonPress; }
  bool mouseButtonReleaseEvent(XEvent &event) { return event.type == ButtonRelease; }
  bool keyPressEvent(XEvent &event)           { return event.type == KeyPress; }

  int getClick() {
    eventQueue.clear();          /* discard previous clicks */
    XEvent event;
    for (;;) {
      nextEvent(event);
      if (event.type == ButtonPress)
        return event.xbutton.x * 65536 + event.xbutton.y;
    }
  }

} /* namespace simplecpp */
