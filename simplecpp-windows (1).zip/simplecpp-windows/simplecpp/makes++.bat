@echo off
setlocal
set "SIMPLECPP=%~dp0"
g++ %* -Wall -std=c++11 -I"%SIMPLECPP%include"
endlocal
