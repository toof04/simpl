@echo off
rem =====================================================================
rem  install.bat  --  make 's++' usable from any folder
rem
rem  Adds this SimpleCpp folder to your *user* PATH (no admin needed),
rem  so you can just type:   s++ myprogram.cpp
rem
rem  Re-run any time; it will not add a duplicate entry.
rem  To undo, run uninstall.bat.
rem =====================================================================
setlocal

rem --- folder this script lives in, without the trailing backslash ---
set "SIMPLECPP=%~dp0"
if "%SIMPLECPP:~-1%"=="\" set "SIMPLECPP=%SIMPLECPP:~0,-1%"

echo Installing SimpleCpp so 's++' works from anywhere...
echo   Folder: %SIMPLECPP%
echo.

rem --- check g++ is available (the wrapper needs it) ---
where g++ >nul 2>nul
if errorlevel 1 (
  echo   WARNING: MinGW-w64 g++ was not found on PATH.
  echo   s++ will be installed, but you must install MinGW-w64 for it to
  echo   compile.  Get it from https://winlibs.com or via MSYS2:
  echo       pacman -S mingw-w64-ucrt-x86_64-gcc
  echo.
)

rem --- add to user PATH via PowerShell (avoids setx 1024-char truncation
rem     and skips if the entry is already present) ---
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$dir = '%SIMPLECPP%';" ^
  "$p = [Environment]::GetEnvironmentVariable('Path','User');" ^
  "if ($null -eq $p) { $p = '' };" ^
  "$parts = $p.Split(';') | Where-Object { $_ -ne '' };" ^
  "if ($parts -contains $dir) {" ^
  "  Write-Host '  Already on your PATH - nothing to change.'" ^
  "} else {" ^
  "  $new = (($parts + $dir) -join ';');" ^
  "  [Environment]::SetEnvironmentVariable('Path', $new, 'User');" ^
  "  Write-Host '  Added to your user PATH.'" ^
  "}"

if errorlevel 1 (
  echo.
  echo   ERROR: could not update PATH automatically.
  echo   Add this folder to your PATH manually:
  echo       %SIMPLECPP%
  exit /b 1
)

echo.
echo Done.  Open a NEW Command Prompt (so it picks up the new PATH), then:
echo     s++ myprogram.cpp
echo     a.exe
echo.
echo (The change affects new terminals only; existing ones keep the old PATH.)
endlocal
