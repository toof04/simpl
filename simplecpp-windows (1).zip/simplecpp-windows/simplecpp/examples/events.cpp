#include <simplecpp>
main_program{
  initCanvas("events", 400, 400);
  Text prompt(200, 30, "Type keys / click; ESC quits");
  Turtle t; t.moveTo(200,200);
  XEvent e;
  while(true){
    nextEvent(e);
    if(keyPressEvent(e)){
      if(KeyCode(e)==KeyCode_ESC) break;
      char c = charFromEvent(e);
      Text show(200,200,string("key: ")+c);
      wait(0.2);
      if(KeyCode(e)==KeyCode_ARROWLEFT) t.left(15);
    }
    if(mouseButtonPressEvent(e)){
      int b = MouseCode(e);
      Circle dot(MousePosX(e), MousePosY(e), 5); dot.setFill(true);
      if(b==Button1) dot.setColor(COLOR("red"));
    }
  }
  closeCanvas();
}
