#include <simplecpp>
main_program{
  initCanvas("Windows SimpleCpp Demo", 500, 500);
  Circle c(250, 250, 100);
  c.setColor(COLOR("red")); c.setFill(true);
  Rectangle r(250, 250, 260, 260);
  r.setColor(COLOR("blue"));
  Text t(250, 60, "Hello, Windows!");
  t.setColor(COLOR("darkgreen"));
  Turtle turt;
  turt.penDown();
  for (int i = 0; i < 5; ++i) { turt.forward(120); turt.right(144); }
  wait(3);
  closeCanvas();
  return 0;
}
