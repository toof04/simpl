#include <simplecpp>
main_program{
  turtleSim();
  for(int i=0;i<4;i++){ forward(100); right(90); }
  penUp(); forward(50); penDown();
  wait(2);
  closeTurtleSim();
}
