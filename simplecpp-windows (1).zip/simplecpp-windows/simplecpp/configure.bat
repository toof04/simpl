@echo off
rem =====================================================================
rem  configure.bat  --  set up SimpleCpp on Windows
rem =====================================================================
setlocal
echo Checking for MinGW-w64 g++ on PATH...
where g++ >nul 2>nul
if errorlevel 1 (
  echo.
  echo   ERROR: g++ not found on PATH.
  echo   Install MinGW-w64 ^(https://winlibs.com or MSYS2^) and add its
  echo   bin folder to PATH, then re-run configure.bat.
  exit /b 1
)
g++ --version | findstr /i "g++" >nul

echo Rebuilding lib\libsprite.a from source...
pushd src
g++ -std=c++11 -O2 -Wall -I..\include -c canvas.cpp polygon.cpp line.cpp circle.cpp sprite.cpp turtle.cpp rectangle.cpp text.cpp turtleSim.cpp sim.cpp
if errorlevel 1 ( echo Build failed. & popd & exit /b 1 )
ar rcs ..\lib\libsprite.a canvas.o polygon.o line.o circle.o sprite.o turtle.o rectangle.o text.o turtleSim.o sim.o
del /Q *.o >nul 2>nul
popd

echo.
echo Done.  Compile programs with:
echo     "%~dp0s++" yourprogram.cpp
echo     .\a.exe
endlocal
