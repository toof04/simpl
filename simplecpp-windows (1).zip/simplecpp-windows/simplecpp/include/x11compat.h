#ifndef _SIMPLECPP_X11COMPAT_INCLUDED_
#define _SIMPLECPP_X11COMPAT_INCLUDED_

/*
 * x11compat.h  --  Windows-native SimpleCpp
 *
 * The original SimpleCpp was written on top of Xlib and let a handful of
 * X11 types and constants leak into its public headers (pose.h, canvas.h)
 * and into user code (XPoint, XEvent, GXcopy, LineSolid, ...).
 *
 * On Windows there is no Xlib, so this header supplies drop-in replacements
 * for exactly those symbols.  It deliberately pulls in NOTHING from
 * <windows.h>; it is pure, portable C++ so that user programs and every
 * SimpleCpp header keep compiling with the same source they always used.
 *
 * The real Win32/GDI machinery lives entirely inside canvas.cpp.
 */

/* --- Geometry ----------------------------------------------------------- */
/* Binary-compatible with the classic X11 XPoint (two shorts). */
typedef struct {
  short x;
  short y;
} XPoint;

/* --- Event model -------------------------------------------------------- */
/* SimpleCpp only ever touches: event.type, event.xbutton.{button,x,y,time},
 * event.xkey.{keycode,state,x,y,time}, event.xmotion.{x,y}.  We reproduce
 * that shape with a small tagged union so existing code is unchanged.      */

typedef unsigned long XTime;

typedef struct {
  int   type;
  int   button;      /* MouseCode: Button1 .. Button5           */
  int   x, y;        /* position in window pixels               */
  XTime time;        /* milliseconds, monotonic                 */
  unsigned int state;
} XButtonEvent;

typedef struct {
  int   type;
  unsigned int keycode; /* Windows virtual-key code (see keycodes.h) */
  unsigned int state;   /* shift/ctrl/alt modifier mask              */
  int   x, y;
  XTime time;
} XKeyEvent;

typedef struct {
  int   type;
  int   x, y;
  XTime time;
  unsigned int state;
} XMotionEvent;

typedef union _XEvent {
  int          type;      /* first field of every member, so this is valid */
  XButtonEvent xbutton;
  XKeyEvent    xkey;
  XMotionEvent xmotion;
} XEvent;

/* --- Event type codes (values mirror X11 for source compatibility) ------ */
#ifndef KeyPress
#define KeyPress        2
#define KeyRelease      3
#define ButtonPress     4
#define ButtonRelease   5
#define MotionNotify    6
#endif

/* --- Mouse buttons ------------------------------------------------------ */
#ifndef Button1
#define Button1 1   /* left       */
#define Button2 2   /* middle     */
#define Button3 3   /* right      */
#define Button4 4   /* scroll up  */
#define Button5 5   /* scroll dn  */
#endif

/* --- Graphics-context constants used as default args in canvas.h -------- */
/* Their numeric values are irrelevant on Windows; the GDI backend ignores
 * them.  They exist only so the public signatures keep their defaults.     */
#ifndef GXcopy
#define GXcopy          3
#endif
#ifndef LineSolid
#define LineSolid       0
#define LineOnOffDash   1
#define LineDoubleDash  2
#endif
#ifndef CapButt
#define CapNotLast      0
#define CapButt         1
#define CapRound        2
#define CapProjecting   3
#endif
#ifndef JoinMiter
#define JoinMiter       0
#define JoinRound       1
#define JoinBevel       2
#endif
#ifndef WindingRule
#define EvenOddRule     0
#define WindingRule     1
#endif
#ifndef Complex
#define Complex         0
#define Nonconvex       1
#define Convex          2
#endif
#ifndef CoordModeOrigin
#define CoordModeOrigin   0
#define CoordModePrevious 1
#endif

/* --- Convenience accessors used by typical SimpleCpp programs ----------- */
#ifndef MouseCode
#define MouseCode(event) ((event).xbutton.button)
#define KeyCode(event)   ((event).xkey.keycode)

#define MouseCode_LEFT      Button1
#define MouseCode_CENTER    Button2
#define MouseCode_RIGHT     Button3
#define MouseCode_SCROLLUP  Button4   /* mouse-wheel up   */
#define MouseCode_SCROLLDN  Button5   /* mouse-wheel down */

#define MousePosX(event) ((event).xbutton.x)
#define MousePosY(event) ((event).xbutton.y)

#define MouseTime(event) ((event).xbutton.time)
#define KeyTime(event)   ((event).xkey.time)
#endif

#endif /* _SIMPLECPP_X11COMPAT_INCLUDED_ */
