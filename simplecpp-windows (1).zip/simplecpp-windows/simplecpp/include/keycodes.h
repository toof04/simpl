#ifndef _SIMPLECPP_KEYCODES_INCLUDED_
#define _SIMPLECPP_KEYCODES_INCLUDED_

/*
 * keycodes.h  --  Windows-native SimpleCpp
 *
 * On Windows the backend reports the Win32 virtual-key code (the wParam of
 * WM_KEYDOWN) in event.xkey.keycode.  These constants are therefore the
 * matching VK_* values, so KeyCode(event) == KeyCode_A behaves as expected.
 * (The original X11 header used Linux hardware scancodes, which are
 *  meaningless on Windows.)
 */

#define KeyCode_ESC              0x1B
#define KeyCode_F1               0x70
#define KeyCode_F2               0x71
#define KeyCode_F3               0x72
#define KeyCode_F4               0x73
#define KeyCode_F5               0x74
#define KeyCode_F6               0x75
#define KeyCode_F7               0x76
#define KeyCode_F8               0x77
#define KeyCode_F9               0x78
#define KeyCode_F10              0x79
#define KeyCode_F11              0x7A
#define KeyCode_F12              0x7B
#define KeyCode_ACUTE            0xC0   /* `~  (VK_OEM_3)  */
#define KeyCode_0                0x30
#define KeyCode_1                0x31
#define KeyCode_2                0x32
#define KeyCode_3                0x33
#define KeyCode_4                0x34
#define KeyCode_5                0x35
#define KeyCode_6                0x36
#define KeyCode_7                0x37
#define KeyCode_8                0x38
#define KeyCode_9                0x39
#define KeyCode_A                0x41
#define KeyCode_B                0x42
#define KeyCode_C                0x43
#define KeyCode_D                0x44
#define KeyCode_E                0x45
#define KeyCode_F                0x46
#define KeyCode_G                0x47
#define KeyCode_H                0x48
#define KeyCode_I                0x49
#define KeyCode_J                0x4A
#define KeyCode_K                0x4B
#define KeyCode_L                0x4C
#define KeyCode_M                0x4D
#define KeyCode_N                0x4E
#define KeyCode_O                0x4F
#define KeyCode_P                0x50
#define KeyCode_Q                0x51
#define KeyCode_R                0x52
#define KeyCode_S                0x53
#define KeyCode_T                0x54
#define KeyCode_U                0x55
#define KeyCode_V                0x56
#define KeyCode_W                0x57
#define KeyCode_X                0x58
#define KeyCode_Y                0x59
#define KeyCode_Z                0x5A
#define KeyCode_SUBTRACT         0xBD   /* -_ (VK_OEM_MINUS) */
#define KeyCode_EQUAL            0xBB   /* =+ (VK_OEM_PLUS)  */
#define KeyCode_BACKSPACE        0x08
#define KeyCode_TAB              0x09
#define KeyCode_CAPS_LOCK        0x14
#define KeyCode_LSHIFT           0xA0
#define KeyCode_RSHIFT           0xA1
#define KeyCode_LALT             0xA4
#define KeyCode_RALT             0xA5
#define KeyCode_LCTRL            0xA2
#define KeyCode_RCTRL            0xA3
#define KeyCode_SPACEBAR         0x20
#define KeyCode_ENTER            0x0D
#define KeyCode_LBRACKET         0xDB   /* [{ (VK_OEM_4) */
#define KeyCode_RBRACKET         0xDD   /* ]} (VK_OEM_6) */
#define KeyCode_BACKSLASH        0xDC   /* \| (VK_OEM_5) */
#define KeyCode_SEMICOLON        0xBA   /* ;: (VK_OEM_1) */
#define KeyCode_QUOTE            0xDE   /* '" (VK_OEM_7) */
#define KeyCode_COMMA            0xBC   /* ,< (VK_OEM_COMMA)  */
#define KeyCode_FULLSTOP         0xBE   /* .> (VK_OEM_PERIOD) */
#define KeyCode_FORWARDSLASH     0xBF   /* /? (VK_OEM_2) */
#define KeyCode_HOME             0x24
#define KeyCode_PAGEUP           0x21
#define KeyCode_PAGEDOWN         0x22
#define KeyCode_END              0x23
#define KeyCode_ARROWUP          0x26
#define KeyCode_ARROWDOWN        0x28
#define KeyCode_ARROWLEFT        0x25
#define KeyCode_ARROWRIGHT       0x27
#define KeyCode_SCROLL           0x91   /* Scroll Lock */
#define KeyCode_PAUSE            0x13
#define KeyCode_INSERT           0x2D
#define KeyCode_DELETE           0x2E
#define KeyCode_NUMLOCK          0x90
#define KeyCode_NUMPADDIVIDE     0x6F
#define KeyCode_NUMPADMULTIPLY   0x6A
#define KeyCode_NUMPADSUBTRACT   0x6D
#define KeyCode_NUMPADPLUS       0x6B
#define KeyCode_NUMPADENTER      0x0D
#define KeyCode_NUMPAD0          0x60
#define KeyCode_NUMPAD1          0x61
#define KeyCode_NUMPAD2          0x62
#define KeyCode_NUMPAD3          0x63
#define KeyCode_NUMPAD4          0x64
#define KeyCode_NUMPAD5          0x65
#define KeyCode_NUMPAD6          0x66
#define KeyCode_NUMPAD7          0x67
#define KeyCode_NUMPAD8          0x68
#define KeyCode_NUMPAD9          0x69
#define KeyCode_NUMPADFULLSTOP   0x6E

#endif /* _SIMPLECPP_KEYCODES_INCLUDED_ */
