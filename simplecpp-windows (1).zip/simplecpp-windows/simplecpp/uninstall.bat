@echo off
rem =====================================================================
rem  uninstall.bat  --  remove this SimpleCpp folder from your user PATH
rem  (reverses install.bat; does not delete any files)
rem =====================================================================
setlocal

set "SIMPLECPP=%~dp0"
if "%SIMPLECPP:~-1%"=="\" set "SIMPLECPP=%SIMPLECPP:~0,-1%"

echo Removing SimpleCpp from your user PATH...
echo   Folder: %SIMPLECPP%

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$dir = '%SIMPLECPP%';" ^
  "$p = [Environment]::GetEnvironmentVariable('Path','User');" ^
  "if ($null -eq $p) { $p = '' };" ^
  "$parts = $p.Split(';') | Where-Object { $_ -ne '' -and $_ -ne $dir };" ^
  "[Environment]::SetEnvironmentVariable('Path', ($parts -join ';'), 'User');" ^
  "Write-Host '  Removed (if it was present).'"

echo.
echo Done.  Open a NEW Command Prompt for the change to take effect.
echo (No files were deleted - to fully remove, just delete this folder.)
endlocal
