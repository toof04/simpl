=====================================================================
 SimpleCpp  --  Windows-native edition
=====================================================================

This is a port of the SimpleCpp graphics package that runs natively on
Microsoft Windows.  The original relied on the X Window System (Xlib);
this edition uses the Win32 API and GDI instead, so NO X server, Cygwin
X, or WSL is required. 
---------------------------------------------------------------------
 1. Requirements
---------------------------------------------------------------------
A MinGW-w64 C++ compiler (g++) on your PATH.  Two easy ways to get it:

  * WinLibs standalone build:  https://winlibs.com
    Unzip and add the "...\mingw64\bin" folder to your PATH.

  * MSYS2 ( https://www.msys2.org ):
        pacman -S mingw-w64-ucrt-x86_64-gcc
    and use the "UCRT64" shell (or add its bin dir to PATH).

Check it works by opening a Command Prompt and running:  g++ --version

---------------------------------------------------------------------
 2. Install
---------------------------------------------------------------------
1. Copy this whole "simplecpp" folder anywhere you like,
   e.g.  C:\simplecpp
2. Open a Command Prompt in that folder and run:
        ./install.bat
   This adds the folder to your user PATH so you can just type "s++"
   from any directory (no admin rights needed).  Open a NEW Command
   Prompt afterwards so it picks up the change.  To undo it later, run
   uninstall.bat.
3. (Optional) run:
        configure.bat
   This checks your compiler and rebuilds lib\libsprite.a from source.
   A prebuilt libsprite.a is already included, so this step is optional.

---------------------------------------------------------------------
 3. Compiling your programs
---------------------------------------------------------------------
From a Command Prompt:

        s++  myprogram.cpp
        a.exe

 s++ is the SimpleCpp compiler wrapper: it invokes g++ with
the right include path, links libsprite.a and the Windows GDI/User
libraries, and produces a.exe by default.




---------------------------------------------------------------------
 4. What is in this folder
---------------------------------------------------------------------
   include\   C++ header files (#include <simplecpp>)
   lib\       libsprite.a          (prebuilt Windows static library)
   src\       library source code + Makefile.win (to rebuild the lib)
   s++.bat    compiler wrapper for the Windows Command Prompt
   makes++.bat  compile-only wrapper (no library link)
   s++        compiler wrapper for MSYS2 / Git-Bash
   install.bat / uninstall.bat    add/remove this folder on your PATH
   configure.bat / configure.sh   optional setup / library rebuild

---------------------------------------------------------------------
 5. Notes on the Windows port
---------------------------------------------------------------------
 * Graphics now use Win32/GDI; a console window and the graphics window
   both appear (cout / cin keep working as usual).
 * Keyboard codes (keycodes.h, KeyCode_A ...) are Windows virtual-key
   codes, and KeyCode(event) returns the same, so key comparisons work.
 * Mouse buttons: Button1 left, Button2 middle, Button3 right;
   Button4 / Button5 are mouse-wheel up / down.
 * Closing the graphics window ends the program.
 * The X11 types your code may have used (XPoint, XEvent) and constants
   (GXcopy, LineSolid, ...) are provided by include\x11compat.h, so old
   SimpleCpp sources compile unchanged.

Rebuilding the library by hand (from src\):
        mingw32-make -f Makefile.win
or just run configure.bat again.
