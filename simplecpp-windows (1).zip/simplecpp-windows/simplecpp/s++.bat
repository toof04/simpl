@echo off
rem =====================================================================
rem  s++  --  SimpleCpp compiler wrapper (Windows / MinGW-w64 g++)
rem
rem  Usage:   s++ myprogram.cpp            (produces a.exe)
rem           s++ myprogram.cpp -o my.exe  (custom output name)
rem
rem  Requires MinGW-w64 g++ on PATH.  Get it from https://winlibs.com or
rem  via MSYS2:  pacman -S mingw-w64-ucrt-x86_64-gcc
rem =====================================================================
setlocal
set "SIMPLECPP=%~dp0"
g++ %* -Wall -std=c++11 -I"%SIMPLECPP%include" "%SIMPLECPP%lib\libsprite.a" -lgdi32 -luser32 -static-libgcc -static-libstdc++
endlocal
