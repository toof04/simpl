#!/bin/sh
# Set up SimpleCpp on Windows under MSYS2 / Git-Bash.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
if ! command -v g++ >/dev/null 2>&1; then
  echo "ERROR: g++ not found. Install MinGW-w64 (e.g. MSYS2) and retry." >&2
  exit 1
fi
echo "Rebuilding lib/libsprite.a ..."
cd "$DIR/src"
g++ -std=c++11 -O2 -Wall -I../include -c \
    canvas.cpp polygon.cpp line.cpp circle.cpp sprite.cpp turtle.cpp \
    rectangle.cpp text.cpp turtleSim.cpp sim.cpp
ar rcs ../lib/libsprite.a *.o
rm -f *.o
echo "Done.  Compile with:  $DIR/s++ yourprogram.cpp && ./a.exe"
